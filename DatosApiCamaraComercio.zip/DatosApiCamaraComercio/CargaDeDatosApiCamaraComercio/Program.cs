﻿using System;
using System.Net.Http;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Media;
using static Program;

class Program
{
    private static string apiUrl = "https://wsinteroperabilidad.ccpsd.do/api/v1";
    private static string authEndpoint = $"{apiUrl}/AuthController/Authenticate";
    private static string dataEndpoint = $"{apiUrl}/CamaraSantoDomingoIntegration/GetMassiveEnterprisesInformation";
    private static string databaseConnectionString = "Data Source=VMSVRSQLDEV01;Initial Catalog=CRIESGOSWEBDEV;Persist Security Info=True;User ID=userfabrica;Password=userfabrica;MultipleActiveResultSets=True; Connection Timeout = 240";
    private static string username = "sbbancos";
    private static string password = "SBIntegra_01*";
    private static string authToken;

    static async Task Main()    
    {
        // Inicialmente, obtén el token de autenticación
        authToken = await Authenticate(authEndpoint, username, password);
        if (!string.IsNullOrEmpty(authToken))
        {
            int currentPage = 13383;
            bool hasMoreData = true;
            int maxRetries = 5;
            int retries = 0;

            using (var httpClient = new HttpClient())
            {
                while (hasMoreData)
                {
                    string requestUrl = $"{dataEndpoint}";                                               
                    var paginationData = new
                    {
                        pagenumber = currentPage,
                        pagesize = 15
                    };
                    var jsonContent = JsonConvert.SerializeObject(paginationData);
                    string response = await SendPostRequestWithToken(httpClient, requestUrl, authToken, jsonContent);

                    if (response != null)
                    {
                        bool success = SaveDataToDatabaseSocios(response, databaseConnectionString, currentPage, 1);
                        while (!success || retries >= 5)
                        {
                            Console.WriteLine($"Error al procesar la página {currentPage}. Intento {retries + 1} de {maxRetries}");
                            Console.WriteLine($"**************************************************************************************");
                            Console.WriteLine($"                                                                                      ");
                            Console.WriteLine($"************************** Intentando insertar nuevamente.. ***************************");
                            Console.WriteLine($"                                                                                      ");
                            Console.WriteLine($"**************************************************************************************");
                            success = SaveDataToDatabaseSocios(response, databaseConnectionString, currentPage, 1);
                            retries++;

                            if (retries >= maxRetries)
                            {
                                Console.WriteLine($"¡Se han agotado los intentos ({maxRetries})! Reproduciendo alarma...");
                                PlayAlarmSound();
                                break;
                            }
                        }
                        if (success)
                        {
                            int totalRegistrosInsertados = currentPage * 15;
                            //totalRegistrosInsertados = totalRegistrosInsertados - 44;
                            Console.WriteLine($"**************************************************************************************");
                            Console.WriteLine($"*********** Página {currentPage} procesada y guardada en la base de datos. ***********");
                            //Console.WriteLine($"                                                                                      ");
                            //Console.WriteLine($"************************* {totalRegistrosInsertados} Registros insertados. **************************");
                            Console.WriteLine($"**************************************************************************************");
                            retries = 0; // Restablece el contador de intentos en caso de éxito.
                        }
                        else
                        {
                            Console.WriteLine($"Error al procesar la página {currentPage}.");
                        }
                    }
                    else
                    {
                        Console.WriteLine($"Error en la solicitud. Intento {retries + 1} de {maxRetries}");
                        retries++;

                        authToken = await Authenticate(authEndpoint, username, password);
                        Console.WriteLine($"****************************************************************************");
                        Console.WriteLine($"**************************** Respuesta Nula... *****************************");
                        Console.WriteLine($"**************** Token actualizado. Intentando nuevamente.. ****************");
                        Console.WriteLine($"****************************************************************************");

                        response = await SendPostRequestWithToken(httpClient, requestUrl, authToken, jsonContent);
                        retries = 1;
                        if (response != null)
                        {
                            bool success = SaveDataToDatabaseSocios(response, databaseConnectionString, currentPage, 1);

                            while (!success || retries >= 3)
                            {
                                Console.WriteLine($"Error al procesar la página {currentPage}. Intento {retries + 1} de {maxRetries}");
                                Console.WriteLine($"**************************************************************************************");
                                Console.WriteLine($"                                                                                      ");
                                Console.WriteLine($"************************** Intentando insertar nuevamente.. ***************************");
                                Console.WriteLine($"                                                                                      ");
                                Console.WriteLine($"**************************************************************************************");
                                success = SaveDataToDatabaseSocios(response, databaseConnectionString, currentPage, 1);
                                retries++;
                            }
                            if (success)
                            {
                                int totalRegistrosInsertados = currentPage * 15;
                                //totalRegistrosInsertados = totalRegistrosInsertados - 44;
                                Console.WriteLine($"**************************************************************************************");
                                Console.WriteLine($"*********** Página {currentPage} procesada y guardada en la base de datos. ***********");
                                //Console.WriteLine($"                                                                                      ");
                                //Console.WriteLine($"************************* {totalRegistrosInsertados} Registros insertados. **************************");
                                Console.WriteLine($"**************************************************************************************");
                                retries = 0; // Restablece el contador de intentos en caso de éxito.
                            }
                            else
                            {
                                Console.WriteLine($"Error al procesar la página {currentPage}.");
                            }
                        }
                        else
                        {
                            while (response == null)
                            {
                                Console.WriteLine($"****************************************************************************");
                                Console.WriteLine($"**************************** Respuesta Nula... *****************************");
                                Console.WriteLine($"                Error en la solicitud. Intento {retries + 1} de {maxRetries}");
                                Console.WriteLine($"**************** Token actualizado. Intentando nuevamente.. ****************");
                                Console.WriteLine($"****************************************************************************");
                                authToken = await Authenticate(authEndpoint, username, password);
                                response = await SendPostRequestWithToken(httpClient, requestUrl, authToken, jsonContent);
                                retries++;
                                if (retries == 5)
                                {
                                    break;
                                }
                            }
                        }
                    }
                    currentPage++;
                    var respuesta = JsonConvert.DeserializeObject<ApiResponse>(response);
                    hasMoreData = respuesta.pagination.pageNumber < respuesta.pagination.pageCount;
                }
            }
        }
        else
        {
            Console.WriteLine("La autenticación falló. No se pudo obtener el token JWT.");
        }
    }
    public static void PlayAlarmSound()
    {
        SoundPlayer player = new SoundPlayer();
        player.SoundLocation = "C:/Users/esantos/Desktop/alarma.wav";
        player.Play();
        Console.ReadKey();
    }
    static async Task<string> Authenticate(string authEndpoint, string username, string password)
    {
        using (var httpClient = new HttpClient())
        {
            var authData = new { AppShortName = "CamaraSantoDomingoIntegration", UserName = username, Password = password };
            var content = new StringContent(JsonConvert.SerializeObject(authData), System.Text.Encoding.UTF8, "application/json");
            var response = await httpClient.PostAsync(authEndpoint, content);

            if (response.IsSuccessStatusCode)
            {
                string responseContent = await response.Content.ReadAsStringAsync();
                var responseObject = JsonConvert.DeserializeObject<AuthResponse>(responseContent);
                if (responseObject != null)
                {
                    return responseObject.authKey;
                }
            }

            return null;
        }
    }
    public class AuthResponse
    {
        public string authKey { get; set; }
    }
    static async Task<string> SendPostRequestWithToken(HttpClient httpClient, string requestUrl, string authToken, string jsonContent)
    {
        try
        {
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {authToken}");
                var content = new StringContent(jsonContent, System.Text.Encoding.UTF8, "application/json");
                var response = await client.PostAsync(requestUrl, content);

                if (response.IsSuccessStatusCode)
                {
                    return await response.Content.ReadAsStringAsync();
                }
                else
                {
                    return null;
                }
            }
        }
        catch (Exception ex)
        {
            return null;
        }
    }
    //static bool SaveDataToDatabase(string jsonData, string connectionString, int currentPage, int currentRecord)
    //{

    //    try
    //    {
    //        var data = JsonConvert.DeserializeObject<DataModel>(jsonData);
    //        if (data != null && data.data != null && data.data.Length > 0)
    //        {
    //            using (var connection = new SqlConnection(connectionString))
    //            {
    //                connection.Open();

    //                foreach (var empresa in data.data)
    //                {
    //                    var command = new SqlCommand(
    //                        "INSERT INTO CC_Empresa (registroMercantil, denominacionSocial, tipoSociedad, identificacion, " +
    //                        "fechaEmision, fechaEmision2, fechaVencimiento, siglas, nacionalidad, capitalSocialAutorizado, " +
    //                        "capitalSuscritoYPagado, moneda, capitalAportado, fechaInicioOperaciones, fechaAsambleaConstitutivaActo, " +
    //                        "fechaUltimaAsamblea, duracionSociedad, calle, sector, municipio, telefono1, telefono2, correoElectonico, " +
    //                        "fax, paginaWeb, actividadDeLaSociedad, objetoSocial, principalesProductosYServicios, sistemaArmonizado, " +
    //                        "estadoActualSociedadPf, cantidadAccionistasSocios, totalAcciones, duracionConsejoDeAdministracionOrganoDeGestion, " +
    //                        "esEnteRegulado, enteRegulado, numeroResolucion, masculinos, femeninos, totalEmpleados, nombreComercial, " +
    //                        "registroNombreComercial, nombreComercial2, registroNombreComercial2, refereciaComerciales, refereciasBancarias, " +
    //                        "comentario, tieneActoAlguacil, actosDeAlguacil, camara) " +
    //                        "VALUES (@registroMercantil, @denominacionSocial, @tipoSociedad, @identificacion, " +
    //                        "@fechaEmision, @fechaEmision2, @fechaVencimiento, @siglas, @nacionalidad, @capitalSocialAutorizado, " +
    //                        "@capitalSuscritoYPagado, @moneda, @capitalAportado, @fechaInicioOperaciones, @fechaAsambleaConstitutivaActo, " +
    //                        "@fechaUltimaAsamblea, @duracionSociedad, @calle, @sector, @municipio, @telefono1, @telefono2, @correoElectonico, " +
    //                        "@fax, @paginaWeb, @actividadDeLaSociedad, @objetoSocial, @principalesProductosYServicios, @sistemaArmonizado, " +
    //                        "@estadoActualSociedadPf, @cantidadAccionistasSocios, @totalAcciones, @duracionConsejoDeAdministracionOrganoDeGestion, " +
    //                        "@esEnteRegulado, @enteRegulado, @numeroResolucion, @masculinos, @femeninos, @totalEmpleados, @nombreComercial, " +
    //                        "@registroNombreComercial, @nombreComercial2, @registroNombreComercial2, @refereciaComerciales, @refereciasBancarias, " +
    //                        "@comentario, @tieneActoAlguacil, @actosDeAlguacil, @camara)", connection);

    //                    int cantidadAccionistasSocios;
    //                    if (int.TryParse(empresa.empresa.cantidadAccionistasSocios, out cantidadAccionistasSocios))
    //                        command.Parameters.AddWithValue("@cantidadAccionistasSocios", cantidadAccionistasSocios);
    //                    else
    //                        command.Parameters.AddWithValue("@cantidadAccionistasSocios", DBNull.Value);


    //                    command.Parameters.AddWithValue("@capitalAportado", decimal.Parse(empresa.empresa.capitalAportado));

    //                    // Añade el tratamiento para las propiedades con valores nulos
    //                    command.Parameters.AddWithValue("@fechaEmision", string.IsNullOrEmpty(empresa.empresa.fechaEmision) ? (object)DBNull.Value : empresa.empresa.fechaEmision);
    //                    command.Parameters.AddWithValue("@fechaEmision2", string.IsNullOrEmpty(empresa.empresa.fechaEmision2) ? (object)DBNull.Value : empresa.empresa.fechaEmision2);
    //                    command.Parameters.AddWithValue("@registroMercantil", string.IsNullOrEmpty(empresa.empresa.registroMercantil) ? (object)DBNull.Value : empresa.empresa.registroMercantil);
    //                    command.Parameters.AddWithValue("@denominacionSocial", string.IsNullOrEmpty(empresa.empresa.denominacionSocial) ? (object)DBNull.Value : empresa.empresa.denominacionSocial);
    //                    command.Parameters.AddWithValue("@tipoSociedad", string.IsNullOrEmpty(empresa.empresa.tipoSociedad) ? (object)DBNull.Value : empresa.empresa.tipoSociedad);
    //                    command.Parameters.AddWithValue("@identificacion", string.IsNullOrEmpty(empresa.empresa.rnc) ? (object)DBNull.Value : empresa.empresa.rnc);
    //                    command.Parameters.AddWithValue("@siglas", string.IsNullOrEmpty(empresa.empresa.siglas) ? (object)DBNull.Value : empresa.empresa.siglas);
    //                    command.Parameters.AddWithValue("@nacionalidad", string.IsNullOrEmpty(empresa.empresa.nacionalidad) ? (object)DBNull.Value : empresa.empresa.nacionalidad);
    //                    command.Parameters.AddWithValue("@capitalSocialAutorizado", string.IsNullOrEmpty(empresa.empresa.capitalSocialAutorizado) ? (object)DBNull.Value : empresa.empresa.capitalSocialAutorizado);
    //                    command.Parameters.AddWithValue("@capitalSuscritoYPagado", string.IsNullOrEmpty(empresa.empresa.capitalSuscritoYPagado) ? (object)DBNull.Value : empresa.empresa.capitalSuscritoYPagado);
    //                    command.Parameters.AddWithValue("@moneda", string.IsNullOrEmpty(empresa.empresa.moneda) ? (object)DBNull.Value : empresa.empresa.moneda);
    //                    command.Parameters.AddWithValue("@duracionSociedad", string.IsNullOrEmpty(empresa.empresa.duracionSociedad) ? (object)DBNull.Value : empresa.empresa.duracionSociedad);
    //                    command.Parameters.AddWithValue("@calle", string.IsNullOrEmpty(empresa.empresa.calle) ? (object)DBNull.Value : empresa.empresa.calle);
    //                    command.Parameters.AddWithValue("@sector", string.IsNullOrEmpty(empresa.empresa.sector) ? (object)DBNull.Value : empresa.empresa.sector);
    //                    command.Parameters.AddWithValue("@municipio", string.IsNullOrEmpty(empresa.empresa.municipio) ? (object)DBNull.Value : empresa.empresa.municipio);
    //                    command.Parameters.AddWithValue("@telefono1", string.IsNullOrEmpty(empresa.empresa.telefono1) ? (object)DBNull.Value : empresa.empresa.telefono1);
    //                    command.Parameters.AddWithValue("@telefono2", string.IsNullOrEmpty(empresa.empresa.telefono2) ? (object)DBNull.Value : empresa.empresa.telefono2);
    //                    command.Parameters.AddWithValue("@correoElectonico", string.IsNullOrEmpty(empresa.empresa.correoElectonico) ? (object)DBNull.Value : empresa.empresa.correoElectonico);
    //                    command.Parameters.AddWithValue("@fax", string.IsNullOrEmpty(empresa.empresa.fax) ? (object)DBNull.Value : empresa.empresa.fax);
    //                    command.Parameters.AddWithValue("@paginaWeb", string.IsNullOrEmpty(empresa.empresa.paginaWeb) ? (object)DBNull.Value : empresa.empresa.paginaWeb);
    //                    command.Parameters.AddWithValue("@actividadDeLaSociedad", string.IsNullOrEmpty(empresa.empresa.actividadDeLaSociedad) ? (object)DBNull.Value : empresa.empresa.actividadDeLaSociedad);
    //                    command.Parameters.AddWithValue("@objetoSocial", string.IsNullOrEmpty(empresa.empresa.objetoSocial) ? (object)DBNull.Value : empresa.empresa.objetoSocial);
    //                    command.Parameters.AddWithValue("@principalesProductosYServicios", string.IsNullOrEmpty(empresa.empresa.principalesProductosYServicios) ? (object)DBNull.Value : empresa.empresa.principalesProductosYServicios);
    //                    command.Parameters.AddWithValue("@fechaInicioOperaciones", string.IsNullOrEmpty(empresa.empresa.fechaInicioOperaciones) ? (object)DBNull.Value : empresa.empresa.fechaInicioOperaciones);
    //                    command.Parameters.AddWithValue("@fechaVencimiento", string.IsNullOrEmpty(empresa.empresa.fechaVencimiento) ? (object)DBNull.Value : empresa.empresa.fechaVencimiento);
    //                    command.Parameters.AddWithValue("@fechaAsambleaConstitutivaActo", string.IsNullOrEmpty(empresa.empresa.fechaAsambleaConstitutivaActo) ? (object)DBNull.Value : empresa.empresa.fechaAsambleaConstitutivaActo);
    //                    command.Parameters.AddWithValue("@fechaUltimaAsamblea", string.IsNullOrEmpty(empresa.empresa.fechaUltimaAsamblea) ? (object)DBNull.Value : empresa.empresa.fechaUltimaAsamblea);
    //                    command.Parameters.AddWithValue("@sistemaArmonizado", string.IsNullOrEmpty(empresa.empresa.sistemaArmonizado) ? (object)DBNull.Value : empresa.empresa.sistemaArmonizado);
    //                    command.Parameters.AddWithValue("@estadoActualSociedadPf", string.IsNullOrEmpty(empresa.empresa.estadoActualSociedadPf) ? (object)DBNull.Value : empresa.empresa.estadoActualSociedadPf);
    //                    command.Parameters.AddWithValue("@totalAcciones", string.IsNullOrEmpty(empresa.empresa.totalAcciones) ? (object)empresa.empresa.totalAcciones : DBNull.Value);
    //                    command.Parameters.AddWithValue("@duracionConsejoDeAdministracionOrganoDeGestion", string.IsNullOrEmpty(empresa.empresa.duracionConsejoDeAdministracionOrganoDeGestion) ? (object)DBNull.Value : empresa.empresa.duracionConsejoDeAdministracionOrganoDeGestion);
    //                    command.Parameters.AddWithValue("@esEnteRegulado", string.IsNullOrEmpty(empresa.empresa.esEnteRegulado) ? (object)DBNull.Value : empresa.empresa.esEnteRegulado);
    //                    command.Parameters.AddWithValue("@enteRegulado", string.IsNullOrEmpty(empresa.empresa.enteRegulado) ? (object)DBNull.Value : empresa.empresa.enteRegulado);
    //                    command.Parameters.AddWithValue("@numeroResolucion", string.IsNullOrEmpty(empresa.empresa.numeroResolucion) ? (object)DBNull.Value : empresa.empresa.numeroResolucion);
    //                    command.Parameters.AddWithValue("@masculinos", string.IsNullOrEmpty(empresa.empresa.masculinos) ? (object)empresa.empresa.masculinos : DBNull.Value);
    //                    command.Parameters.AddWithValue("@femeninos", string.IsNullOrEmpty(empresa.empresa.femeninos) ? (object)empresa.empresa.femeninos : DBNull.Value);
    //                    command.Parameters.AddWithValue("@totalEmpleados", string.IsNullOrEmpty(empresa.empresa.totalEmpleados) ? (object)empresa.empresa.totalEmpleados : DBNull.Value);
    //                    command.Parameters.AddWithValue("@nombreComercial", string.IsNullOrEmpty(empresa.empresa.nombreComercial) ? (object)DBNull.Value : empresa.empresa.nombreComercial);
    //                    command.Parameters.AddWithValue("@registroNombreComercial", string.IsNullOrEmpty(empresa.empresa.registroNombreComercial) ? (object)DBNull.Value : empresa.empresa.registroNombreComercial);
    //                    command.Parameters.AddWithValue("@nombreComercial2", string.IsNullOrEmpty(empresa.empresa.nombreComercial2) ? (object)DBNull.Value : empresa.empresa.nombreComercial2);
    //                    command.Parameters.AddWithValue("@registroNombreComercial2", string.IsNullOrEmpty(empresa.empresa.registroNombreComercial2) ? (object)DBNull.Value : empresa.empresa.registroNombreComercial2);
    //                    command.Parameters.AddWithValue("@refereciaComerciales", string.IsNullOrEmpty(empresa.empresa.refereciaComerciales) ? (object)DBNull.Value : empresa.empresa.refereciaComerciales);
    //                    command.Parameters.AddWithValue("@refereciasBancarias", string.IsNullOrEmpty(empresa.empresa.refereciasBancarias) ? (object)DBNull.Value : empresa.empresa.refereciasBancarias);
    //                    command.Parameters.AddWithValue("@comentario", string.IsNullOrEmpty(empresa.empresa.comentario) ? (object)DBNull.Value : empresa.empresa.comentario);
    //                    command.Parameters.AddWithValue("@tieneActoAlguacil", string.IsNullOrEmpty(empresa.empresa.tieneActoAlguacil) ? (object)DBNull.Value : empresa.empresa.tieneActoAlguacil);
    //                    command.Parameters.AddWithValue("@actosDeAlguacil", string.IsNullOrEmpty((string?)empresa.empresa.actosDeAlguacil) ? (object)DBNull.Value : empresa.empresa.actosDeAlguacil);
    //                    command.Parameters.AddWithValue("@camara", string.IsNullOrEmpty(empresa.empresa.camara) ? (object)DBNull.Value : empresa.empresa.camara);


    //                    command.ExecuteNonQuery();
    //                    Console.WriteLine($"Registro {currentRecord} Insertado con Exito.");
    //                    currentRecord++;
    //                }
    //            }
    //            return true;
    //        }
    //        else
    //        {
    //            Console.WriteLine("No se encontraron datos válidos en la respuesta JSON.");
    //            return false;
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        Console.WriteLine($"Error en la Página {currentPage}, registro {currentRecord}.");
    //        Console.WriteLine($"Error al guardar los datos en la base de datos: {ex.Message}");
    //        return false;
    //    }
    //}
    static void PlayErrorSound()
    {
        // Reproduce un sonido de alarma en caso de error
        using (var player = new SoundPlayer("error.wav")) // Reemplaza "error.wav" con la ubicación de tu archivo de sonido
        {
            player.Play();
        }
    }
    public class DataModel
    {
        public Data[] data { get; set; }
    }
    public class Data
    {
        public Empresa Empresa { get; set; }
        public List<Socios> Socios { get; set; }
    }
    public class Empresa
    {
        public string registroMercantil { get; set; }
        public string denominacionSocial { get; set; }
        public string tipoSociedad { get; set; }
        public string rnc { get; set; }
        public string fechaEmision { get; set; }
        public string fechaEmision2 { get; set; }
        public string fechaVencimiento { get; set; }
        public string siglas { get; set; }
        public string nacionalidad { get; set; }
        public string capitalSocialAutorizado { get; set; }
        public string capitalSuscritoYPagado { get; set; }
        public string moneda { get; set; }
        public string capitalAportado { get; set; }
        public string fechaInicioOperaciones { get; set; }
        public string fechaAsambleaConstitutivaActo { get; set; }
        public string fechaUltimaAsamblea { get; set; }
        public string duracionSociedad { get; set; }
        public string calle { get; set; }
        public string sector { get; set; }
        public string municipio { get; set; }
        public string telefono1 { get; set; }
        public string telefono2 { get; set; }
        public string correoElectonico { get; set; }
        public string fax { get; set; }
        public string paginaWeb { get; set; }
        public string actividadDeLaSociedad { get; set; }
        public string objetoSocial { get; set; }
        public string principalesProductosYServicios { get; set; }
        public string sistemaArmonizado { get; set; }
        public string estadoActualSociedadPf { get; set; }
        public string cantidadAccionistasSocios { get; set; }
        public string totalAcciones { get; set; }
        public string duracionConsejoDeAdministracionOrganoDeGestion { get; set; }
        public string esEnteRegulado { get; set; }
        public string enteRegulado { get; set; }
        public string numeroResolucion { get; set; }
        public string masculinos { get; set; }
        public string femeninos { get; set; }
        public string totalEmpleados { get; set; }
        public string nombreComercial { get; set; }
        public string registroNombreComercial { get; set; }
        public string nombreComercial2 { get; set; }
        public string registroNombreComercial2 { get; set; }
        public string refereciaComerciales { get; set; }
        public string refereciasBancarias { get; set; }
        public string comentario { get; set; }
        public string tieneActoAlguacil { get; set; }
        public object actosDeAlguacil { get; set; }
        public string camara { get; set; }
    }
    public class ApiResponse
    {
        public Pagination pagination { get; set; }
        // Otros campos según tu estructura de respuesta
    }
    public class Pagination
    {
        public int pageNumber { get; set; }
        public int pageSize { get; set; }
        public int totalItemCount { get; set; }
        public int pageCount { get; set; }
    }

    /////////////////////////////SOCIOS
    public class Socios
    {
        public string NombreSocio { get; set; }
        public string DocumentoSocio { get; set; }
        public string Nacionalidad { get; set; }
        public string Posicion { get; set; }
        public string Relaciones { get; set; }
        public string Cargo { get; set; }
        public string RegistroMercantil { get; set; }
        public string DenominacionSocial { get; set; }
        public string RncEmpresa { get; set; }
        public string CantidadAcciones { get; set; }
        public string Direccion { get; set; }
    }
    static bool SaveDataToDatabaseSocios(string jsonData, string connectionString, int currentPage, int currentRecord)
    {
        try
        {
            var data = JsonConvert.DeserializeObject<DataModel>(jsonData);
            if (data != null && data.data != null && data.data.Length > 0)
            {
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    foreach (var socio in data.data)
                    {
                        foreach (var item in socio.Socios)
                        {
                            var command = new SqlCommand(
                            "INSERT INTO CC_Socios (NombreSocio, DocumentoSocio, Nacionalidad, Posicion, Relaciones, " +
                            "Cargo, RegistroMercantil, DenominacionSocial, RncEmpresa, CantidadAcciones, Direccion) " +
                            "VALUES (@NombreSocio, @DocumentoSocio, @Nacionalidad, @Posicion, @Relaciones, " +
                            "@Cargo, @RegistroMercantil, @DenominacionSocial, @RncEmpresa, @CantidadAcciones, @Direccion)", connection);

                            command.Parameters.AddWithValue("@NombreSocio", string.IsNullOrEmpty(item.NombreSocio) ? (object)DBNull.Value : item.NombreSocio);
                            command.Parameters.AddWithValue("@DocumentoSocio", string.IsNullOrEmpty(item.DocumentoSocio) ? (object)DBNull.Value : item.DocumentoSocio);
                            command.Parameters.AddWithValue("@Nacionalidad", string.IsNullOrEmpty(item.Nacionalidad) ? (object)DBNull.Value : item.Nacionalidad);
                            command.Parameters.AddWithValue("@Posicion", string.IsNullOrEmpty(item.Posicion) ? (object)DBNull.Value : item.Posicion);
                            command.Parameters.AddWithValue("@Relaciones", string.IsNullOrEmpty(item.Relaciones) ? (object)DBNull.Value : item.Relaciones);
                            command.Parameters.AddWithValue("@Cargo", string.IsNullOrEmpty(item.Cargo) ? (object)DBNull.Value : item.Cargo);
                            command.Parameters.AddWithValue("@RegistroMercantil", string.IsNullOrEmpty(item.RegistroMercantil) ? (object)DBNull.Value : item.RegistroMercantil);
                            command.Parameters.AddWithValue("@DenominacionSocial", string.IsNullOrEmpty(item.DenominacionSocial) ? (object)DBNull.Value : item.DenominacionSocial);
                            command.Parameters.AddWithValue("@RncEmpresa", string.IsNullOrEmpty(item.RncEmpresa) ? (object)DBNull.Value : item.RncEmpresa);
                            command.Parameters.AddWithValue("@CantidadAcciones", string.IsNullOrEmpty(item.CantidadAcciones) ? (object)DBNull.Value : item.CantidadAcciones);
                            command.Parameters.AddWithValue("@Direccion", string.IsNullOrEmpty(item.Direccion) ? (object)DBNull.Value : item.Direccion);

                            command.ExecuteNonQuery();
                            Console.WriteLine($"Registro {currentRecord} Insertado con Exito.");
                            currentRecord++;
                        }
                    }
                }
                return true;
            }
            else
            {
                Console.WriteLine("No se encontraron datos válidos en la respuesta JSON.");
                return false;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error en la Página {currentPage}, registro {currentRecord}.");
            Console.WriteLine($"Error al guardar los datos en la base de datos: {ex.Message}");
            return false;
        }
    }

}
